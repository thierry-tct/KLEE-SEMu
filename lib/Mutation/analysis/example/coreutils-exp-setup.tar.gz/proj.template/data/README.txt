# COREUTILS: git clone https://github.com/coreutils/coreutils.git

 We use the version v8.22

 After cloning, do: 
 > git checkout tags/v8.22

 # 
 ProjList.txt is taken  from config.status, "built_programs"
