
import os, sys
import json
import argparse
import shutil

def loadJson(filename):
    with open(filename) as f:
        return json.load(f)
#~def loadJson()

def dumpJson (data, filename):
    with open(filename, 'w') as f:
        json.dump(data, f)
#~ def dumpJson()

template_TOOLNAME = "TOOLNAME"
SEP="_"

def getPathNames (destdir, toolname, templatedir, filenamesuffix):
    templatefilename = "".join([template_TOOLNAME, SEP, filenamesuffix])
    destfilename = "".join([toolname, SEP, filenamesuffix])
    templatefilepath = os.path.join(templatedir, templatefilename)
    destfilepath = os.path.join(destdir, destfilename)
    return templatefilepath, destfilepath
#def getPathNames()

def createKLeeCallArgs (destdir, toolname, templatedir, datadir):
    templatefilepath, destfilepath = getPathNames (destdir, toolname, templatedir, "klee-args-template.args")
    symargsObj = loadJson(os.path.join(datadir, "klee_symargs.json"))
    if toolname in symargsObj["SPECIFIC"]:
        symargs = symargsObj["SPECIFIC"][toolname]
    else:
        symargs = symargsObj["DEFAULT"]
    
    with open(templatefilepath) as f:
        kleecmd_tp = f.read()

    symArgTemplate = "__SYMBOLIC_ARGS__"
    assert symArgTemplate in kleecmd_tp
    kleecmd = kleecmd_tp.replace(symArgTemplate, symargs)
    with open(destfilepath, 'w') as f:
        f.write(kleecmd)
#~ def createKLeeCallArgs()

'''
    expensive = 0(only normal), 1(normal and expensive), 2(normal, expensive and very expensive)
'''
def createTestsList (destdir, toolname, templatedir, datadir, allTests, expensive=0, addhelpversion=True, addinvalidopt=True):
    templatefilepath, destfilepath = getPathNames (destdir, toolname, templatedir, "testscases.txt")
    loaded_testlistObj = loadJson(os.path.join(datadir, "raw-testslists.json"))
    tool2testlist = loadJson(os.path.join(datadir, "tool2testslists.json"))

    if len(allTests) == 0:
        for tccat in loaded_testlistObj:
            allTests += loaded_testlistObj[tccat]["ALL"]

    # add other skipped to normal XXX TODO: rmove thie
    #loaded_testlistObj["NORMAL"]["ALL"] += loaded_testlistObj["OTHER-SKIPPED"]["ALL"]

    # get everything related to the tool
    testlistObj = {tccat: {toolname: []} for tccat in ["NORMAL", "ROOT", "EXPENSIVE", "VERY-EXPENSIVE"]}

    for tccat in testlistObj:
        if tool2testlist is None:
            for tc in loaded_testlistObj[tccat]["ALL"]:
                split = os.path.normpath(tc).split(os.path.sep) 
                assert len(split) == 3, "test not having format: tests/<folder>/<testname>. ("+tc+")"
                if split[1] == toolname or split[1].startswith(toolname+"-"):
                    testlistObj[tccat][toolname].append(tc)
                elif split[1] == "misc" and (split[2].startswith(toolname+".") or split[2].startswith(toolname+"-")):
                    testlistObj[tccat][toolname].append(tc)
        else:
            testlistObj[tccat][toolname] = list(set(loaded_testlistObj[tccat]["ALL"]) & set(tool2testlist[toolname]))

    if addhelpversion:
        testlistObj["NORMAL"][toolname].append("tests/misc/help-version.sh")
    if addinvalidopt:
        testlistObj["NORMAL"][toolname].append("tests/misc/invalid-opt.pl")

    testlist = []
    roottests = testlistObj["ROOT"][toolname]
    assert expensive in range(3), "expensive must be eithe 0, 1 or 2"
    testlist += testlistObj["NORMAL"][toolname]
    testlist += roottests
    if expensive >= 1:
        if toolname in testlistObj["EXPENSIVE"]:
            testlist += testlistObj["EXPENSIVE"][toolname]
        if expensive >= 2:
            if toolname in testlistObj["VERY-EXPENSIVE"]:
                testlist += testlistObj["VERY-EXPENSIVE"][toolname]
    #assert len(testlist) > 0+int(addhelpversion), "Empty testlist for Tool: "+toolname
    with open(destfilepath, "w") as f:
        for tc in testlist:
            f.write(tc+"\n")
    return testlist, roottests
#~ def createTestsList

def createSourceList (destdir, toolname, templatedir, datadir, withHeaders=False):
    templatefilepath, destfilepath = getPathNames (destdir, toolname, templatedir, "srclist.txt")
    srclistObj = loadJson(os.path.join(datadir, "srcfiles.json"))
    srclist = []
    # For now just put everything
    srclist += srclistObj["SOURCES"] 
    if withHeaders:
        srclist += srclistObj["HEADERS"]
    assert len(srclist) > 0, "Empty srclist for Tool: "+toolname
    with open(destfilepath, "w") as f:
        for src in srclist:
            f.write(src+"\n")
#~ def createSourceList ()

def createMutationScope (destdir, toolname, templatedir, datadir):
    templatefilepath, destfilepath = getPathNames (destdir, toolname, templatedir, "mutation-scope.json")
    scopesObj = loadJson(os.path.join(datadir, "mutationScopes.json"))
    funclist = []
    srclist = set()
    assert toolname in scopesObj, "tool is not in scopesObj: '"+toolname+"'"
    for covf in scopesObj[toolname]:
        src, func = covf.split(":")
        funclist.append(func)
        srclist.add(src)
    srclist = list(srclist)
    K_Func = "Functions"
    K_Src = "Source-Files"
    oso = loadJson(templatefilepath)
    assert set([K_Func, K_Src]) == set(oso)
    oso[K_Func] = funclist
    oso[K_Src] = srclist
    dumpJson(oso, destfilepath)
#~ def createMutationScope()

def create_Conf_Build_Runtest_Scripts (destdir, toolname, templatedir, datadir, roottests, expensive=0):
    conf_templatefilepath, conf_destfilepath = getPathNames (destdir, toolname, templatedir, "conf-script.conf")
    build_templatefilepath, build_destfilepath = getPathNames (destdir, toolname, templatedir, "build.sh")
    runtests_templatefilepath, runtests_destfilepath = getPathNames (destdir, toolname, templatedir, "runtests.sh")

    bugfixpatch_templatefilepath, bugfixpatch_destfilepath = getPathNames (destdir, toolname, templatedir, "bugfix.patch")

    projID_mr = ("__PROJECT_ID__", toolname)
    tool_mr = ("__TOOLNAME__", toolname)
    expensive_mr = ("#export RUN_EXPENSIVE_TESTS=yes", "export RUN_EXPENSIVE_TESTS=yes")
    veryexpensive_mr = ("#export RUN_VERY_EXPENSIVE_TESTS=yes", "export RUN_VERY_EXPENSIVE_TESTS=yes")
    roottests_mr = ("__ROOT_TESTS_STRING_EXPORT__", " ".join(roottests))

    def apply (templ_file, dst_file, mr_list):
        with open(templ_file) as f:
            tmplstr  = f.read()
        dststr = None
        if mr_list is None:
            dststr = tmplstr
        else:
            for mr in mr_list:
                assert mr[0] in tmplstr, "template string ("+tmplstr+") is not in template file ("+templ_file+")"
                dststr = tmplstr.replace(mr[0], mr[1])
                tmplstr = dststr
        assert dststr is not None, "mr_list is empty. Must not be"
        with open(dst_file, 'w') as f:
            f.write(dststr)

    apply(conf_templatefilepath, conf_destfilepath, [projID_mr, tool_mr])
    apply(build_templatefilepath, build_destfilepath, None) #[projID_mr, tool_mr])
    if os.system("chmod +x "+build_destfilepath) != 0:
        assert False, "Failed to set the destination build script executable"
    rtapp = [roottests_mr]
    assert expensive in range(3), "expensive must be eithe 0, 1 or 2"
    if expensive >= 1:
        rtapp.append(expensive_mr)
        if expensive >= 2:
            rtapp.append(veryexpensive_mr)
    apply(runtests_templatefilepath, runtests_destfilepath, rtapp)
    if os.system("chmod +x "+runtests_destfilepath) != 0:
        assert False, "Failed to set the destination runtests script executable"

    apply(bugfixpatch_templatefilepath, bugfixpatch_destfilepath, None)
#~ def create_Conf_Build_Runtest_Scripts()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("outMetaCtrlDir", type=str, help="metactrl dir where the project should be placed")
    parser.add_argument("--cleanexistingdir", action='store_true', help="delete everything from each Tools meta dir")
    parser.add_argument("--withhelpversion", action='store_true', help="Consider the test help-version")
    parser.add_argument("--expensiveTestsLevel", type=int, choices=range(3), default=2, help="Set 0, 1 or 2 to consider normal, expensive and very expensive tests")
    parser.add_argument("--selectedtools", type=str, default=None, help="Optionally set the tools to process. If not set, all tools are processed")
    args = parser.parse_args()

    topdir = os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))
    templatedir = os.path.join(topdir, "metaTemplate")
    datadir = os.path.join(topdir, "data")
    allTools = [s.strip() for s in open(os.path.join(datadir, "ProjList.txt"))]

    outTopDir = os.path.abspath(args.outMetaCtrlDir)
    cleanexistingdir = args.cleanexistingdir
    withHelpVersion = args.withhelpversion
    expensive = args.expensiveTestsLevel
    if args.selectedtools is not None:
        selTools = args.selectedtools.strip().split()
    else:
        selTools = allTools
    assert len(set(selTools) - set(allTools)) == 0, "Some specified tools are not valid toolnames: "+str(set(selTools) - set(allTools)) 

    # Actual computations
    print "# Processing", len(selTools), "Tools, into:", outTopDir
    tot_tests = set()
    allTests = []
    notesttools = []
    for toolname in selTools:
        destdir = os.path.join(outTopDir, toolname)
        if not os.path.isdir(destdir):
            os.makedirs(destdir)
        elif cleanexistingdir:
            shutil.rmtree(destdir)
            os.makedirs(destdir)

        tooltests, roottests = createTestsList(destdir, toolname, templatedir, datadir, allTests, expensive, addhelpversion=withHelpVersion, addinvalidopt=True)
        if len(tooltests) <= 0 + int(withHelpVersion):
            notesttools.append(toolname)
            continue
        tot_tests |= set(tooltests)
        create_Conf_Build_Runtest_Scripts(destdir, toolname, templatedir, datadir, roottests, expensive)
        createKLeeCallArgs(destdir, toolname, templatedir, datadir)
        createSourceList(destdir, toolname, templatedir, datadir)
        createMutationScope(destdir, toolname, templatedir, datadir)

    if len(notesttools) > 0:
        print "\n# Tools having no test:", notesttools
        #dumpJson({s:[] for s in notesttools}, os.path.join(datadir,"manual_tool2tests.json"))
    print "# Selected tools:", len(selTools), "Tool Considered (with tests):", len(selTools)-len(notesttools)
    #print set(allTests) - set(tot_tests) 
    print "## Number of unique tests:", len(tot_tests), "All tests:", len(allTests)
    #with open(os.path.join(datadir, "raw-testlist.txt"), "w") as f:
    #    for tc in allTests:
    #        f.write(tc+"\n")
    print "# Done !"
#~ def main()

if __name__ == "__main__":
    main()
