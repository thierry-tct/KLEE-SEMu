#! /bin/bash

error_exit()
{
    echo "ERROR: $1"
    exit 1
}

doscp=0
if [ $# -eq 1 ]; then
    [ $1 != "scp" ] && error_exit "param must be scp"
    doscp=1
else
    [ $# -ne 0 ] && error_exit "wrong param num"
fi

topdir=$(dirname `readlink -f $0`)
reposdir=$(readlink -f $topdir/../../repos)
metadir=$(readlink -f $topdir/../../metactrl)

dispatchdir=$(readlink -f $topdir/../../dispatch)
nonroottools=$dispatchdir/non_rootteststools
roottools=$dispatchdir/rootteststools
for direct in $roottools $nonroottools
do
    mkdir -p $direct/workspace/metactrl $direct/workspace/repos
    rm -rf $direct/workspace/metactrl/* $direct/workspace/repos/*
    echo "# Copying repos.."
    cp -rf $reposdir/coreutils $direct/workspace/repos || error_exit "copy failed repos"
done

echo "# Copying metactrls"
for p in `ls $metadir`
do
    runtest=$metadir/$p/$p"_runtests.sh"
    if grep '^if `echo "  " | grep " $TC " > /dev/null`' $runtest > /dev/null
    then
        cp -rf $metadir/$p $nonroottools/workspace/metactrl || error_exit "cp failed non root"
    else
        cp -rf $metadir/$p $roottools/workspace/metactrl || error_exit "cp failed root"
    fi
done

echo "# Ready."
r_num=`ls $roottools/workspace/metactrl | wc -l`
nr_num=`ls $nonroottools/workspace/metactrl | wc -l`
if [ `ls $metadir | wc -l` -ne $(($r_num + $nr_num)) ]; then
    error_exit "Not all project processed"
fi
if [ $doscp -eq 1 ]
then
    # Copy them
    rootDest="ttitcheuchekam@access-gaia.uni.lu:/scratch/users/ttitcheuchekam/SEMU_EXPERIMENTS/MutantExecution/"
    nonrootDest="ttitcheuchekam@access-gaia.uni.lu:/scratch/users/ttitcheuchekam/SEMU_EXPERIMENTS/MutantExecution/"

    ## actual copy
    echo "Copyting non-roots..."
    scp -r -P 8022 $nonroottools $nonrootDest > /dev/null || error_exit "scp 1 failed"
    echo "Copyting roots..."
    scp -r -P 8022 $roottools $rootDest > /dev/null || error_exit "scp 1 failed"
fi

echo "Done!"
