#! /bin/bash
set -u

error_exit()
{
    echo "ERROR: $1"
    exit 1
}

topdir=$(readlink -f `dirname $0`)
repodir=$(readlink -f $topdir/../../repos/expr)

if [ $# = 1 ]
then
    repodir=$(readlink -f $1)
fi

testlist=$(readlink -f $topdir/../data/raw-testlist.txt)
projList=$(readlink -f $topdir/../data/ProjList.txt)
test -f $testlist || error_exit "raw-testlist missing: '$testlist'"
test -f $projList || error_exit "projList missing: '$projList'"
test -d $repodir || error_exit "repos dir not found: '$repodir'"

outfile=$(readlink -f $topdir/../data/tool2testslists.json)
test -d `dirname $outfile` || error_exit "outfile parent non existing. outfil is '$outfile'"

# get map
tmpmap=$topdir/tmpmap.txt.tmp
echo -n > $tmpmap
while read tc
do
    # Special cases
    if [ "$tc" = "tests/misc/mknod.sh" ] || [ "$tc" = "tests/dd/no-allocate.sh" ]; then  grep 'mkfifo' $projList > /dev/null &&  echo "mkfifo $tc" >> $tmpmap; 
    elif [ "$tc" = "tests/mv/i-3.sh" ]; then grep 'uname' $projList > /dev/null &&  echo "uname $tc" >> $tmpmap; 
    elif [ "$tc" = "tests/misc/ls-misc.pl" ] || [ "$tc" = "tests/misc/csplit-suppress-matched.pl" ] || [ "$tc" = "tests/misc/mktemp.pl" ]; then grep 'unlink' $projList > /dev/null &&  echo "unlink $tc" >> $tmpmap; 
    elif [ "$tc" = "tests/tail-2/retry.sh" ] || [ "$tc" = "tests/tail-2/symlink.sh" ]; then grep '\[' $projList > /dev/null &&  echo "[ $tc" >> $tmpmap; 
    fi

    tcpath=$repodir/$tc
    test -f $tcpath || error_exit "test file not found: '$tc' -> '$tcpath'"
    if [ "${tcpath: -3}" = ".sh" ]; then 
        line=`grep "^print_ver_ " $tcpath`
        if  [ "$line" != "" ]; then
            tools=$(echo $line | cut -d' ' -f2-)
            seentools=0
            for i in $tools 
            do
                if ! grep "^$i$" $projList > /dev/null; then
                    echo "> test '$tc' has and invalid tool: '$i'"
                else
                    echo "$i $tc" >> $tmpmap
                fi
            done
        else
            if [ "$tc" = "tests/tail-2/inotify-rotate.sh" ]; then grep 'tail' $projList > /dev/null &&  echo "tail $tc" >> $tmpmap; 
            elif [ "$(dirname $tc)" = "tests/du" ]; then grep 'du' $projList > /dev/null &&  echo "du $tc" >> $tmpmap; 
            elif [ "$tc" = "tests/misc/help-version.sh" ] || [ "$tc" = "tests/misc/invalid-opt.pl" ] ; then echo -n;
            else
                #error_exit ".sh testcase has no print_ver_: '$tc'"
                echo "@@@ .sh testcase has no print_ver_: '$tc'"
            fi
        fi
    elif [ "${tcpath: -3}" = ".pl" ]; then
        i=$(grep 'my $prog = ' $tcpath | awk '{print $4}' | cut -d"'" -f2)
        if ! grep "^$i$" $projList > /dev/null; then
            if [ "$tc" = "tests/misc/head-elide-tail.pl" ]; then grep "head" $projList > /dev/null && echo "head $tc" >> $tmpmap;
            elif [ "$tc" = "tests/misc/test-diag.pl" ]; then grep "test" $projList > /dev/null && echo "test $tc" >> $tmpmap;
        
            else
                echo "> test '$tc' has and invalid tool: '$i'"
            fi
        else
            echo "$i $tc" >> $tmpmap
        fi
    elif [ "${tcpath: -4}" = ".xpl" ]; then
        grep '^my $rm = "$ENV{abs_top_builddir}/src/rm";' $tcpath > /dev/null || error_exit ".xpl for tool different than rm: test: $tc"
        echo "rm $tc" >> $tmpmap
    else
        error_exit "Invalid test type '$TC'"
    fi
done < $testlist

# compute json
echo "{" > $outfile
while read tool
do
    echo -n "    \"$tool\": [" >> $outfile
    gt="$tool"
    [ "$gt" = "[" ] && gt="\\["  #grep has issues with [
    grep "^$gt " $tmpmap | awk '{print $2}' | sed 's|^|"|g; s|$|",|g' | tr '\n' ' ' | sed 's|, $||g' >> $outfile
    echo "]," >> $outfile
done < $projList
echo "}" >> $outfile

# remove last column
nlines=$(cat $outfile | wc -l)
lastc=$(($nlines-1))
sed -i'' "$lastc s|,$||" $outfile

rm -f $tmpmap

echo "# DONE!"
