#!/bin/bash
# Build script for (1) rm
#Note: Make sure that here, all used tool are refered with absolute path (to avoid a control command to be considered as a test)
set -u
error_exit()
{
    /bin/echo $1
    exit 1
}

[ $# = 3 ] || error_exit "Error: build script expected 3 parameters, $# provided: <$0> <compiler> <CFLAGS> <mode: [ build(make distclean,bootstrap, config, make); clean-make(make clean, make); make]>"
COMPILER=$1
CFLAGS=$2
MODE=$3
rootDir=$MFI_ROOTDIR

calldir=`/bin/pwd`
cd $rootDir

/bin/rm -f $MFI_EXEDIR/$MFI_PROGRAM

# for klee
[ "$COMPILER" = "wllvm" ] && CFLAGS+=" -std=c89"

if [ "$MODE" = "build" ]
then
    { make clean && make distclean; } || ./bootstrap --skip-po || error_exit "Error: make clean/distclean and bootstrap failed. (in $0)"
    ./configure --disable-nls CC=$COMPILER CFLAGS="-Wno-error $CFLAGS" || error_exit "Error: configure failed. (in $0)"
    #repair Makefile...
    #echo "all: ;" > doc/Makefile
    #echo "all: ;" > po/Makefile

    # Add optimiser script's test  log entry into tests' makefile
    #testcaseDir="tests/expr"
    #cat $(dirname $0)/mfi_ktest-replay-optimizer.testlog >> $rootDir/$testcaseDir/Makefile || error_exit "Failed to add optimizer test log. (in $0)"
    make CC=$COMPILER CFLAGS="-Wno-error $CFLAGS" || error_exit "Error: build: make failed. (in $0)"
    make CC=$COMPILER CFLAGS="-Wno-error $CFLAGS" src/$MFI_PROGRAM || error_exit "Error: build: make failed. (in $0)"

    # Generate factor's tests
    if [ "$MFI_PROGRAM" = "factor" ]; then
        make check-TESTS TESTS="tests/factor/t00.sh tests/factor/t01.sh tests/factor/t02.sh tests/factor/t03.sh tests/factor/t04.sh tests/factor/t05.sh tests/factor/t06.sh tests/factor/t07.sh tests/factor/t08.sh tests/factor/t09.sh tests/factor/t10.sh tests/factor/t11.sh tests/factor/t12.sh tests/factor/t13.sh tests/factor/t14.sh tests/factor/t15.sh tests/factor/t16.sh tests/factor/t17.sh tests/factor/t18.sh tests/factor/t19.sh tests/factor/t20.sh tests/factor/t21.sh tests/factor/t22.sh tests/factor/t23.sh tests/factor/t24.sh tests/factor/t25.sh tests/factor/t26.sh tests/factor/t27.sh tests/factor/t28.sh tests/factor/t29.sh tests/factor/t30.sh tests/factor/t31.sh tests/factor/t32.sh tests/factor/t33.sh tests/factor/t34.sh tests/factor/t35.sh tests/factor/t36.sh"
    fi
elif [ "$MODE" = "clean-make" ]
then
    make clean || error_exit "Error: make clean failed. (clean-make in $0)"
    make CC=$COMPILER CFLAGS="-Wno-error $CFLAGS" || error_exit "Error: clean-make: make failed. (in $0)"
    make CC=$COMPILER CFLAGS="-Wno-error $CFLAGS" src/$MFI_PROGRAM || error_exit "Error: clean-make: make failed. (in $0)"
elif [ "$MODE" = "make" ]
then
    make CC=$COMPILER CFLAGS="-Wno-error $CFLAGS" src/$MFI_PROGRAM || error_exit "Error: make: make failed. (in $0)"
else
    error_exit "Error: Wrong build mode: $MODE. (in $0)"
fi

test -f src/$MFI_PROGRAM || error_exit "Executable file src/$MFI_PROGRAM missing after built"

cd $calldir

# *** wllvm can't generate BC when the extension is not .o, .so,...
### $COMPILER $CFLAGS -c `dirname $0`/src/main.c -o `dirname $0`/src/main.o	#Compile	

### $COMPILER $CFLAGS -o `dirname $0`/src/mainT `dirname $0`/src/main.o	#link

